/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chainofresponsability;



/**
 *
 * @author JéssicaFerreira
 */
public class ValidacaoA extends LoginChain {       
    
	// Sobreescreve método da classe pai LoginChain
	public boolean validacao(String login) {
		// se passou na minha validação, passa pra próxima
    	if(this.validarCaracterMaiusculo(login))
    	{
    		// verifica se existe próximo
    		if(this.hasNext())
    		{
    			// se existe, passa a responsabilidade pra ele
    			return this.next.validacao(login);
    		}
    		else
    		{
    			// se não existe próximo, chegamos ao fim da corrente
    			System.out.println("Validação terminou com sucesso: " + login);   
    			return true;
    		}
    	}    		
    	else
    		return false;    		
    }
    
	// Valida se tem algum char maiúsculo
    public boolean validarCaracterMaiusculo(String login) {
    	char ch;
        
        for(int i=0;i < login.length();i++) {
            ch = login.charAt(i);
            if (Character.isUpperCase(ch)) {
                return true;
            } 
        }
        
        System.out.println("Login não contem char maiúsculo: " + login);  
        
        return false;
    }   
}
