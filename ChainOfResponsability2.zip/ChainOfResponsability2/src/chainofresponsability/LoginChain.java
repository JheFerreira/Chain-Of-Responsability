/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chainofresponsability;

/**
 *
 * @author JéssicaFerreira
 * Classe que vai implementar a cadeia de responsabilidades.
 */
public abstract class LoginChain {
    //Atributos 
    protected LoginChain next; //referência para o próxmo objeto da corrente.    
   
    // seta o proximo objeto
    public void setNext(LoginChain forma){
       this.next = forma;        
    }     
     
    // metodo que valida
    public abstract boolean validacao(String login);      
    
    // verifica se existe proximo
    public boolean hasNext() {
    	// se não tiver next, não existe mais o próximo
    	if(this.next == null)
    		return false;
    	else
    		return true;
    }
}
