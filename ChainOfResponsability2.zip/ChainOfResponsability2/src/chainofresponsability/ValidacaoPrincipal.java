package chainofresponsability;

public class ValidacaoPrincipal {
	ValidacaoA a = new ValidacaoA();
	ValidacaoB b = new ValidacaoB();
	ValidacaoC c = new ValidacaoC();
	
	// cria os objetos e cria o link entre eles
	public ValidacaoPrincipal() {
		a.setNext(b);	
		b.setNext(c);	
	}	
	
	// função principal a ser chamada no main.
	// chama apenas a validação no primeiro objeto, ele se encarrega de chamar a corrente, e as próximas validações
	public boolean test(String login)
	{
		return a.validacao(login);
	}
}
